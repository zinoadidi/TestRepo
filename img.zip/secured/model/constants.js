
var currentPage = '';
var currentComponent = '';
var dashboardApp = null;
var temporaryApp = null;


 var dashboardApp = ''
 var navApp = '';
 var dashboardTitle = {
 	id:'',
 	vm:{
 		title:''
 	}
 	
 };

 var globalLinkVar = '';
 var loginClass = '';
	